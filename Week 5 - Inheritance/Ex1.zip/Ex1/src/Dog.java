public class Dog extends Animal{
    public void getInfo (){
        System.out.println("Dog Cry");
        System.out.println("Dog Walk");
    }
}
