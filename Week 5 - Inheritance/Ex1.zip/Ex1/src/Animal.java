public class Animal {
    public String cry;
    public String walk;
        public Animal (){
        }
        public void getInfo (){
            System.out.println("Animal Cry");
            System.out.println("Animal Walk");
        }
}
