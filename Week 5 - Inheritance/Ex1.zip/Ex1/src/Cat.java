public class Cat extends Animal {
    public void getInfo (){
        System.out.println("Cat Cry");
        System.out.println("Cat Walk");
    }
}
