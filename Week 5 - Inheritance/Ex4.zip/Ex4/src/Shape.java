// Shape class
public class Shape {
    public double getArea() {
        return 0.0;
    }
    
    public double getPerimeter() {
        return 0.0;
    }
}
